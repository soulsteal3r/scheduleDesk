<?php
$LANG = array(
	'title'				=> '9-А LIT',
	'imgEmpty'			=> 'у пользователя нет фотографии',
	'imgEmptyByHash'	=> 'фотографии по тегу <b>#{$hashtag}</b> не найдены '
);
