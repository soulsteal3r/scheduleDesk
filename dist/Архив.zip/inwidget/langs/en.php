<?php
$LANG = array(
	'title'				=> '9-А LIT',
	'imgEmpty'			=> 'user doesn\'t have any photos yet',
	'imgEmptyByHash'	=> 'photos by tag <b>#{$hashtag}</b> not found'
);
